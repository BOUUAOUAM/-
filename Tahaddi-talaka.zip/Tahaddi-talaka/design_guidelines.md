# TALAKA - Reading Fluency Assessment App Design Guidelines

## Architecture Decisions

### Authentication
**No Authentication Required**
- Single-user educational assessment tool with local-only data storage
- Include a Settings screen with:
  - Language preference toggle (Arabic/French)
  - App theme customization
  - Option to set default assessor name
  - Data management (export, clear history)

### Navigation Structure
**Stack-Only Navigation with Floating Action**
- Primary Flow: Assessment Screen → History Screen → Settings Screen
- Use a persistent floating action button on the Assessment screen for quick access to History
- Stack-based navigation allows natural back flow from History to Assessment

**Screen Hierarchy:**
1. **Assessment Screen** (Home/Root)
   - Core action: Start/Stop timer for reading assessment
   - Floating button: History icon (bottom-right)
2. **History Screen** (Modal presentation)
   - Accessed via floating button or tab from Assessment
   - Full-screen modal with close button
3. **Settings Screen** (Stack push from header button)
   - Accessed via gear icon in Assessment screen header

## Screen Specifications

### 1. Assessment Screen (Root)
**Purpose:** Primary interface for conducting reading fluency assessments

**Layout:**
- Header: 
  - Title: Bilingual display "تطبيق قياس طلاقة القراءة / Évaluation de Fluence"
  - Right button: Settings gear icon
  - Left button: Language toggle indicator (AR/FR)
  - Transparent background
- Main Content:
  - Scrollable form layout
  - Auto-populated date field (read-only, displays current date)
  - Input fields: Student name, total words, errors
  - Timer display section with large digital readout
  - Action buttons: Start/Stop timer, Calculate & Save
  - Results display section (correct words, WPM, seconds)
- Floating Elements:
  - History FAB (bottom-right): Circular button with list icon
  - Safe area insets: 
    - Top: insets.top + Spacing.xl
    - Bottom: insets.bottom + Spacing.xl (for FAB clearance add extra Spacing.xxl)
    - Horizontal: Spacing.lg

**Components:**
- Text inputs with bilingual placeholders
- Numeric steppers for word/error counts
- Large timer display (00:00 format)
- Prominent action buttons with clear visual states
- Results cards with large typography for readability
- Language toggle chip in header

**Visual Feedback:**
- Timer pulses during active countdown
- Start button transforms to Stop when active
- Calculate button only enabled when timer is stopped
- Results section highlights with subtle animation on calculate

### 2. History Screen (Modal)
**Purpose:** View and manage past assessment records

**Layout:**
- Header:
  - Title: "سجل الطلاقة / Registre"
  - Left button: Close (X icon)
  - Right button: Export CSV icon
  - Non-transparent background
- Main Content:
  - Scrollable list of assessment cards
  - Each card displays: Student name, date, WPM, correct words, time
  - Empty state: Illustration + text "No assessments yet"
  - Footer: Clear History button (destructive action)
- Safe area insets:
  - Top: Spacing.xl
  - Bottom: insets.bottom + Spacing.xl

**Components:**
- List cards with left-to-right swipe for delete action
- Export floating button or header action
- Clear history button with confirmation modal
- Empty state illustration
- Search/filter bar (optional, if history grows large)

### 3. Settings Screen (Stack Push)
**Purpose:** Configure app preferences and manage data

**Layout:**
- Header:
  - Title: "الإعدادات / Paramètres"
  - Left button: Back arrow
  - Standard navigation header
- Main Content:
  - Scrollable form with grouped sections:
    - Language & Display
    - Default Values
    - Data Management
    - About
- Safe area insets:
  - Top: Spacing.xl
  - Bottom: insets.bottom + Spacing.xl

**Components:**
- Toggle switches for preferences
- Text input for default assessor name
- Destructive buttons for clear history/reset
- Info cards for app version and credits

## Design System

### Color Palette
**Primary Colors:**
- Primary: #2b7a78 (teal - for primary actions, timer)
- Accent: #ef476f (pink-red - for stop button, errors)
- Success: #06d6a0 (green - for positive results)

**Neutral Colors:**
- Background: #f7f7fb (light gray-blue)
- Card Background: #ffffff
- Text Primary: #222222
- Text Secondary: #666666
- Border: #e0e0e0

**Semantic Colors:**
- Error: #ef476f
- Warning: #ffd166
- Info: #7b61ff

### Typography
**Font Family:** System default with Arabic support (iOS: SF Arabic, Android: Roboto + Noto Sans Arabic)

**Hierarchy:**
- Display (Assessment Title): 24pt, Bold, bilingual spacing
- Heading 1 (Screen Titles): 20pt, Semibold
- Heading 2 (Section Headers): 18pt, Medium
- Body: 16pt, Regular
- Label: 14pt, Medium
- Caption: 12pt, Regular
- Timer Display: 48pt, Bold, monospace

**RTL Support:**
- Automatic text direction based on language selection
- Mirror layout elements (buttons, icons) for Arabic
- Maintain number directionality (LTR) even in RTL mode

### Components

**Input Fields:**
- Rounded corners: 8px
- Border: 1px solid #e0e0e0
- Focus state: 2px solid Primary color
- Padding: 12px vertical, 16px horizontal
- Bilingual placeholder text

**Buttons:**
- Primary (Start): Background Primary, white text, rounded 8px
- Secondary (Stop): Background Accent, white text, rounded 8px
- Tertiary (Calculate): Background Success, white text, rounded 8px
- Ghost (Clear History): Background transparent, text color, border 1px
- Height: 48px minimum for touch targets
- Pressed state: 90% opacity
- Disabled state: 40% opacity

**Timer Display:**
- Large digital readout with monospace font
- Background: subtle card with light border
- Color changes: inactive (gray) → active (Primary) → stopped (Accent)
- Padding: 20px

**History Cards:**
- White background with subtle shadow
- Border radius: 12px
- Padding: 16px
- Swipeable with delete action reveal
- Tap to expand for details (optional)

**Floating Action Button:**
- Circular: 56px diameter
- Background: Primary color
- Icon: White list/history icon (Feather: list)
- Shadow specifications:
  - shadowOffset: {width: 0, height: 2}
  - shadowOpacity: 0.10
  - shadowRadius: 2
- Position: 16px from bottom, 16px from right (RTL: left)

**Language Toggle:**
- Chip-style toggle in header
- Shows current language code (AR/FR)
- Subtle background tint
- Tap to switch with smooth transition

### Visual Design Elements

**Icons:**
- Use Feather icons from @expo/vector-icons
- Primary icons: settings (gear), history (list), export (download), timer (clock), calculate (check-circle)
- Icon size: 24px for navigation, 20px for inline

**Spacing Scale:**
- xs: 4px
- sm: 8px
- md: 12px
- lg: 16px
- xl: 24px
- xxl: 32px

**Shadows:**
- Card shadow: shadowOffset {width: 0, height: 1}, shadowOpacity: 0.05, shadowRadius: 3
- FAB shadow: (as specified above)
- Modal shadow: shadowOffset {width: 0, height: 4}, shadowOpacity: 0.12, shadowRadius: 8

**Transitions:**
- Language switch: 300ms ease
- Timer state changes: 200ms
- Results appear: 400ms with subtle scale
- Modal present/dismiss: 300ms slide

### Assets
**No custom illustrations required** - Use system icons and clean typography-focused design. If adding visual interest:
- Optional: Simple geometric pattern for empty states
- Optional: Minimalist book/reading icon for app icon/branding

### Accessibility
- Minimum touch target: 44x44px
- High contrast text (WCAG AA compliance)
- Support for system font scaling (up to 200%)
- Screen reader labels for all interactive elements (bilingual)
- Timer provides haptic feedback on start/stop (if device supports)
- Color is not the only indicator (pair with icons/text)