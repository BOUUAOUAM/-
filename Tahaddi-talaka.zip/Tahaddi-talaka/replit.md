# TALAKA - Reading Fluency Assessment App

## Overview
TALAKA is a bilingual (Arabic/French) mobile application designed for educators to assess students' reading fluency. The app measures words per minute (WPM) and tracks student progress over time.

## Current State
- **Version**: 1.0.0
- **Status**: MVP Complete - Frontend Prototype
- **Platform**: Expo (React Native)

## Key Features
1. **Assessment Screen**: Timer-based reading assessment with input for student name, total words read, and errors
2. **Bilingual Support**: Full Arabic (RTL) and French language switching
3. **Results Calculation**: Automatic calculation of correct words and WPM
4. **History Screen**: View and manage past assessments with swipe-to-delete
5. **Settings Screen**: Language preferences and data management
6. **CSV Export**: Export assessment data for external analysis

## Project Architecture

### Navigation Structure
- Stack-based navigation (no tab bar)
- Assessment Screen (Root) -> History Screen (Modal) -> Settings Screen (Stack)
- Floating Action Button for quick history access

### Key Files
- `App.tsx` - Main app entry with providers
- `navigation/RootStackNavigator.tsx` - Navigation configuration
- `screens/AssessmentScreen.tsx` - Main assessment interface
- `screens/HistoryScreen.tsx` - Assessment history list
- `screens/SettingsScreen.tsx` - App configuration
- `contexts/LanguageContext.tsx` - Bilingual translations
- `contexts/AssessmentContext.tsx` - In-memory data storage

### Design System
- Colors defined in `constants/theme.ts`
- Primary: #2b7a78 (teal)
- Accent: #ef476f (coral)
- Success: #06d6a0 (green)
- iOS 26 Liquid Glass design principles

## User Preferences
- Language preference: Default French
- RTL support for Arabic text
- Haptic feedback on interactions

## Recent Changes
- Initial MVP implementation (Dec 2025)
- Bilingual interface (Arabic/French)
- Timer functionality with start/stop controls
- Assessment history with in-memory storage
- CSV export functionality

## Technical Notes
- Uses in-memory storage (no persistence between app restarts)
- Hot reload enabled - no restart needed for code changes
- Expo Go compatible
