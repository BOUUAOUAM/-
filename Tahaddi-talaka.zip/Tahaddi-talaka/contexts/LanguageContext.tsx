import React, { createContext, useContext, useState, ReactNode } from "react";

type Language = "ar" | "fr";

interface Translations {
  appTitle: string;
  appSubtitle: string;
  language: string;
  learnerName: string;
  learnerNamePlaceholder: string;
  date: string;
  totalWords: string;
  errors: string;
  time: string;
  start: string;
  stop: string;
  calculateSave: string;
  correctWords: string;
  wpm: string;
  seconds: string;
  history: string;
  clearHistory: string;
  exportCSV: string;
  settings: string;
  noHistory: string;
  noHistoryDesc: string;
  confirmClear: string;
  confirmClearDesc: string;
  cancel: string;
  confirm: string;
  defaultAssessor: string;
  defaultAssessorPlaceholder: string;
  languageSettings: string;
  dataManagement: string;
  about: string;
  version: string;
  credits: string;
  creditsText: string;
  delete: string;
  assessmentSaved: string;
  fillFields: string;
  exportSuccess: string;
  resultsCleared: string;
  ranking: string;
  viewRanking: string;
  viewList: string;
  rankingByDay: string;
  selectDate: string;
  noRankingData: string;
  rank: string;
  allRecords: string;
}

const translations: Record<Language, Translations> = {
  ar: {
    appTitle: "تطبيق قياس طلاقة القراءة",
    appSubtitle: "حساب عدد الكلمات الصحيحة في الدقيقة",
    language: "اللغة",
    learnerName: "اسم المتعلم(ة)",
    learnerNamePlaceholder: "مثال: يوسف",
    date: "التاريخ",
    totalWords: "مجموع الكلمات المقروءة",
    errors: "عدد الأخطاء",
    time: "الزمن بالثواني",
    start: "انطلق",
    stop: "إيقاف",
    calculateSave: "احسب و احفظ",
    correctWords: "الكلمات الصحيحة",
    wpm: "المعدل (كلمة/دقيقة)",
    seconds: "ثواني",
    history: "سجل الطلاقة",
    clearHistory: "مسح السجل",
    exportCSV: "تصدير CSV",
    settings: "الإعدادات",
    noHistory: "لا توجد تقييمات بعد",
    noHistoryDesc: "ابدأ بإجراء تقييم جديد",
    confirmClear: "تأكيد المسح",
    confirmClearDesc: "هل أنت متأكد من حذف جميع السجلات؟",
    cancel: "إلغاء",
    confirm: "تأكيد",
    defaultAssessor: "اسم المقيم الافتراضي",
    defaultAssessorPlaceholder: "أدخل اسمك",
    languageSettings: "اللغة والعرض",
    dataManagement: "إدارة البيانات",
    about: "حول التطبيق",
    version: "الإصدار",
    credits: "المساهمون",
    creditsText: "تم تطويره لدعم تقييم طلاقة القراءة",
    delete: "حذف",
    assessmentSaved: "تم حفظ التقييم بنجاح",
    fillFields: "يرجى ملء جميع الحقول",
    exportSuccess: "تم تصدير البيانات بنجاح",
    resultsCleared: "تم مسح جميع السجلات",
    ranking: "الترتيب",
    viewRanking: "عرض الترتيب",
    viewList: "عرض القائمة",
    rankingByDay: "ترتيب المتعلمين حسب اليوم",
    selectDate: "اختر التاريخ",
    noRankingData: "لا توجد بيانات لهذا اليوم",
    rank: "المرتبة",
    allRecords: "جميع السجلات",
  },
  fr: {
    appTitle: "Évaluation de Fluence",
    appSubtitle: "Calcul du nombre de mots corrects par minute",
    language: "Langue",
    learnerName: "Nom de l'élève",
    learnerNamePlaceholder: "Exemple: Amina",
    date: "Date",
    totalWords: "Mots totaux lus",
    errors: "Nombre d'erreurs",
    time: "Temps (secondes)",
    start: "Démarrer",
    stop: "Arrêter",
    calculateSave: "Calculer et Sauvegarder",
    correctWords: "Mots corrects",
    wpm: "Mots/minute",
    seconds: "Secondes",
    history: "Registre de Fluence",
    clearHistory: "Effacer le registre",
    exportCSV: "Exporter CSV",
    settings: "Paramètres",
    noHistory: "Aucune évaluation",
    noHistoryDesc: "Commencez par une nouvelle évaluation",
    confirmClear: "Confirmer l'effacement",
    confirmClearDesc: "Voulez-vous vraiment supprimer tous les enregistrements?",
    cancel: "Annuler",
    confirm: "Confirmer",
    defaultAssessor: "Nom de l'évaluateur par défaut",
    defaultAssessorPlaceholder: "Entrez votre nom",
    languageSettings: "Langue et Affichage",
    dataManagement: "Gestion des données",
    about: "À propos",
    version: "Version",
    credits: "Crédits",
    creditsText: "Développé pour soutenir l'évaluation de la fluence en lecture",
    delete: "Supprimer",
    assessmentSaved: "Évaluation sauvegardée avec succès",
    fillFields: "Veuillez remplir tous les champs",
    exportSuccess: "Données exportées avec succès",
    resultsCleared: "Tous les enregistrements ont été effacés",
    ranking: "Classement",
    viewRanking: "Voir le classement",
    viewList: "Voir la liste",
    rankingByDay: "Classement des élèves par jour",
    selectDate: "Sélectionner la date",
    noRankingData: "Aucune donnée pour cette date",
    rank: "Rang",
    allRecords: "Tous les enregistrements",
  },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>("fr");

  const value: LanguageContextType = {
    language,
    setLanguage,
    t: translations[language],
    isRTL: language === "ar",
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
