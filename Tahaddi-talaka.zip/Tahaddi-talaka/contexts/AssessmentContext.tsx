import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@talaka_assessment_records";

export interface AssessmentRecord {
  id: string;
  learnerName: string;
  date: string;
  totalWords: number;
  errors: number;
  correctWords: number;
  wpm: number;
  seconds: number;
}

interface AssessmentContextType {
  records: AssessmentRecord[];
  addRecord: (record: Omit<AssessmentRecord, "id">) => void;
  deleteRecord: (id: string) => void;
  clearRecords: () => void;
  isLoading: boolean;
  getRankingsByDate: (date: string) => AssessmentRecord[];
  getUniquesDates: () => string[];
}

const AssessmentContext = createContext<AssessmentContextType | undefined>(undefined);

interface AssessmentProviderProps {
  children: ReactNode;
}

export function AssessmentProvider({ children }: AssessmentProviderProps) {
  const [records, setRecords] = useState<AssessmentRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadRecords();
  }, []);

  const loadRecords = async () => {
    try {
      const storedRecords = await AsyncStorage.getItem(STORAGE_KEY);
      if (storedRecords) {
        setRecords(JSON.parse(storedRecords));
      }
    } catch (error) {
      console.error("Error loading records:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveRecords = async (newRecords: AssessmentRecord[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newRecords));
    } catch (error) {
      console.error("Error saving records:", error);
    }
  };

  const addRecord = (record: Omit<AssessmentRecord, "id">) => {
    const newRecord: AssessmentRecord = {
      ...record,
      id: Date.now().toString(),
    };
    const newRecords = [newRecord, ...records];
    setRecords(newRecords);
    saveRecords(newRecords);
  };

  const deleteRecord = (id: string) => {
    const newRecords = records.filter((record) => record.id !== id);
    setRecords(newRecords);
    saveRecords(newRecords);
  };

  const clearRecords = () => {
    setRecords([]);
    saveRecords([]);
  };

  const getRankingsByDate = (date: string): AssessmentRecord[] => {
    const dateRecords = records.filter((record) => record.date === date);
    return dateRecords.sort((a, b) => b.wpm - a.wpm);
  };

  const getUniquesDates = (): string[] => {
    const dates = records.map((record) => record.date);
    return [...new Set(dates)];
  };

  const value: AssessmentContextType = {
    records,
    addRecord,
    deleteRecord,
    clearRecords,
    isLoading,
    getRankingsByDate,
    getUniquesDates,
  };

  return (
    <AssessmentContext.Provider value={value}>
      {children}
    </AssessmentContext.Provider>
  );
}

export function useAssessment() {
  const context = useContext(AssessmentContext);
  if (context === undefined) {
    throw new Error("useAssessment must be used within an AssessmentProvider");
  }
  return context;
}
