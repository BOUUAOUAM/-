import { useEffect, useRef, useCallback } from "react";
import { Platform } from "react-native";
import { useAudioPlayer } from "expo-audio";

const START_SOUND_URI = "https://cdn.freesound.org/previews/352/352661_5540421-lq.mp3";
const STOP_SOUND_URI = "https://cdn.freesound.org/previews/263/263133_2064400-lq.mp3";

export function useSounds() {
  const startPlayer = useAudioPlayer(START_SOUND_URI);
  const stopPlayer = useAudioPlayer(STOP_SOUND_URI);

  const playStartSound = useCallback(async () => {
    try {
      if (Platform.OS === "web") {
        const audio = new Audio(START_SOUND_URI);
        audio.volume = 0.5;
        await audio.play();
      } else {
        startPlayer.seekTo(0);
        startPlayer.play();
      }
    } catch (error) {
      console.log("Could not play start sound:", error);
    }
  }, [startPlayer]);

  const playStopSound = useCallback(async () => {
    try {
      if (Platform.OS === "web") {
        const audio = new Audio(STOP_SOUND_URI);
        audio.volume = 0.5;
        await audio.play();
      } else {
        stopPlayer.seekTo(0);
        stopPlayer.play();
      }
    } catch (error) {
      console.log("Could not play stop sound:", error);
    }
  }, [stopPlayer]);

  return {
    playStartSound,
    playStopSound,
  };
}
