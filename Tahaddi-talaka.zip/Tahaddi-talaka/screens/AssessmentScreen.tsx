import React, { useState, useRef, useEffect } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  Alert,
  Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withRepeat,
  withTiming,
  cancelAnimation,
} from "react-native-reanimated";
import * as Haptics from "expo-haptics";

import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAssessment } from "@/contexts/AssessmentContext";
import { useSounds } from "@/hooks/useSounds";
import { Colors, Spacing, BorderRadius, Shadows, Fonts } from "@/constants/theme";
import { RootStackParamList } from "@/navigation/RootStackNavigator";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function AssessmentScreen() {
  const navigation = useNavigation<NavigationProp>();
  const { theme, isDark } = useTheme();
  const { t, language, setLanguage, isRTL } = useLanguage();
  const { addRecord } = useAssessment();
  const { playStartSound, playStopSound } = useSounds();
  const insets = useSafeAreaInsets();

  const [learnerName, setLearnerName] = useState("");
  const [totalWords, setTotalWords] = useState("");
  const [errors, setErrors] = useState("");
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [correctWords, setCorrectWords] = useState(0);
  const [wpm, setWpm] = useState(0);
  const [hasResults, setHasResults] = useState(false);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerPulse = useSharedValue(1);
  const fabScale = useSharedValue(1);
  const resultsOpacity = useSharedValue(0);

  const today = new Date().toLocaleDateString(language === "ar" ? "ar-MA" : "fr-FR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isRunning) {
      timerPulse.value = withRepeat(
        withTiming(1.05, { duration: 500 }),
        -1,
        true
      );
    } else {
      cancelAnimation(timerPulse);
      timerPulse.value = withSpring(1);
    }
  }, [isRunning]);

  const formatTime = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStart = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    await playStartSound();
    setIsRunning(true);
    setHasResults(false);
    timerRef.current = setInterval(() => {
      setSeconds((prev) => prev + 1);
    }, 1000);
  };

  const handleStop = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    await playStopSound();
    setIsRunning(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const handleCalculateSave = () => {
    if (!learnerName.trim() || !totalWords || seconds === 0) {
      Alert.alert(t.fillFields);
      return;
    }

    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    const total = parseInt(totalWords, 10) || 0;
    const errorCount = parseInt(errors, 10) || 0;
    const correct = Math.max(0, total - errorCount);
    const wordsPerMinute = seconds > 0 ? Math.round((correct / seconds) * 60) : 0;

    setCorrectWords(correct);
    setWpm(wordsPerMinute);
    setHasResults(true);
    resultsOpacity.value = withSpring(1);

    addRecord({
      learnerName: learnerName.trim(),
      date: today,
      totalWords: total,
      errors: errorCount,
      correctWords: correct,
      wpm: wordsPerMinute,
      seconds,
    });

    setTimeout(() => {
      setLearnerName("");
      setTotalWords("");
      setErrors("");
      setSeconds(0);
      setCorrectWords(0);
      setWpm(0);
      setHasResults(false);
      resultsOpacity.value = 0;
    }, 2000);
  };

  const handleLanguageToggle = () => {
    setLanguage(language === "ar" ? "fr" : "ar");
  };

  const timerAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: timerPulse.value }],
  }));

  const fabAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: fabScale.value }],
  }));

  const resultsAnimatedStyle = useAnimatedStyle(() => ({
    opacity: resultsOpacity.value,
    transform: [{ scale: 0.95 + resultsOpacity.value * 0.05 }],
  }));

  const inputStyle = [
    styles.input,
    {
      backgroundColor: theme.backgroundDefault,
      color: theme.text,
      borderColor: theme.border,
      textAlign: isRTL ? ("right" as const) : ("left" as const),
    },
  ];

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <Pressable
          onPress={() => navigation.navigate("Settings")}
          style={({ pressed }) => [
            styles.headerButton,
            { opacity: pressed ? 0.7 : 1 },
          ]}
        >
          <Feather name="settings" size={22} color={theme.text} />
        </Pressable>
      ),
      headerLeft: () => (
        <Pressable
          onPress={handleLanguageToggle}
          style={({ pressed }) => [
            styles.languageChip,
            {
              backgroundColor: isDark ? Colors.dark.primary : Colors.light.primary,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <ThemedText style={styles.languageChipText}>
            {language === "ar" ? "AR" : "FR"}
          </ThemedText>
        </Pressable>
      ),
    });
  }, [navigation, theme, language, isDark]);

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <ScreenKeyboardAwareScrollView
        contentContainerStyle={styles.scrollContent}
      >
        <View style={[styles.subtitleContainer, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <ThemedText type="caption" style={[styles.subtitle, { color: theme.textSecondary }]}>
            {t.appSubtitle}
          </ThemedText>
        </View>

        <View style={[styles.card, { backgroundColor: theme.backgroundDefault }, Shadows.card]}>
          <View style={styles.formRow}>
            <ThemedText type="label" style={[styles.label, { textAlign: isRTL ? "right" : "left" }]}>
              {t.learnerName}
            </ThemedText>
            <TextInput
              style={inputStyle}
              value={learnerName}
              onChangeText={setLearnerName}
              placeholder={t.learnerNamePlaceholder}
              placeholderTextColor={theme.textSecondary}
            />
          </View>

          <View style={styles.formRow}>
            <ThemedText type="label" style={[styles.label, { textAlign: isRTL ? "right" : "left" }]}>
              {t.date}
            </ThemedText>
            <View style={[styles.input, styles.dateField, { backgroundColor: theme.backgroundSecondary, borderColor: theme.border }]}>
              <ThemedText style={{ textAlign: isRTL ? "right" : "left" }}>{today}</ThemedText>
            </View>
          </View>

          <View style={styles.twoColumns}>
            <View style={styles.column}>
              <ThemedText type="label" style={[styles.label, { textAlign: isRTL ? "right" : "left" }]}>
                {t.totalWords}
              </ThemedText>
              <TextInput
                style={inputStyle}
                value={totalWords}
                onChangeText={setTotalWords}
                keyboardType="numeric"
                placeholder="0"
                placeholderTextColor={theme.textSecondary}
              />
            </View>
            <View style={styles.column}>
              <ThemedText type="label" style={[styles.label, { textAlign: isRTL ? "right" : "left" }]}>
                {t.errors}
              </ThemedText>
              <TextInput
                style={inputStyle}
                value={errors}
                onChangeText={setErrors}
                keyboardType="numeric"
                placeholder="0"
                placeholderTextColor={theme.textSecondary}
              />
            </View>
          </View>
        </View>

        <View style={[styles.card, styles.timerCard, { backgroundColor: theme.backgroundDefault }, Shadows.card]}>
          <Animated.View style={[styles.timerContainer, timerAnimatedStyle]}>
            <ThemedText
              type="timer"
              style={[
                styles.timerText,
                {
                  color: isRunning
                    ? isDark ? Colors.dark.primary : Colors.light.primary
                    : theme.text,
                  fontFamily: Fonts?.mono || "monospace",
                },
              ]}
            >
              {formatTime(seconds)}
            </ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary }}>
              {t.time}
            </ThemedText>
          </Animated.View>

          <View style={styles.buttonRow}>
            {!isRunning ? (
              <Pressable
                onPress={handleStart}
                style={({ pressed }) => [
                  styles.actionButton,
                  styles.startButton,
                  { backgroundColor: isDark ? Colors.dark.primary : Colors.light.primary },
                  { opacity: pressed ? 0.9 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] },
                ]}
              >
                <Feather name="play" size={20} color="#FFFFFF" style={styles.buttonIcon} />
                <ThemedText style={styles.buttonText}>{t.start}</ThemedText>
              </Pressable>
            ) : (
              <Pressable
                onPress={handleStop}
                style={({ pressed }) => [
                  styles.actionButton,
                  styles.stopButton,
                  { backgroundColor: isDark ? Colors.dark.accent : Colors.light.accent },
                  { opacity: pressed ? 0.9 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] },
                ]}
              >
                <Feather name="square" size={18} color="#FFFFFF" style={styles.buttonIcon} />
                <ThemedText style={styles.buttonText}>{t.stop}</ThemedText>
              </Pressable>
            )}

            <Pressable
              onPress={handleCalculateSave}
              disabled={isRunning || seconds === 0}
              style={({ pressed }) => [
                styles.actionButton,
                styles.calculateButton,
                {
                  backgroundColor: isDark ? Colors.dark.success : Colors.light.success,
                  opacity: isRunning || seconds === 0 ? 0.4 : pressed ? 0.9 : 1,
                  transform: [{ scale: pressed && !isRunning && seconds > 0 ? 0.98 : 1 }],
                },
              ]}
            >
              <Feather name="check-circle" size={20} color="#FFFFFF" style={styles.buttonIcon} />
              <ThemedText style={styles.buttonText}>{t.calculateSave}</ThemedText>
            </Pressable>
          </View>
        </View>

        <Animated.View
          style={[
            styles.resultsContainer,
            resultsAnimatedStyle,
            { display: hasResults ? "flex" : "none" },
          ]}
        >
          <View style={[styles.card, { backgroundColor: theme.backgroundDefault }, Shadows.card]}>
            <View style={styles.resultsRow}>
              <View style={styles.resultItem}>
                <ThemedText type="label" style={[styles.resultLabel, { color: theme.textSecondary }]}>
                  {t.correctWords}
                </ThemedText>
                <ThemedText
                  type="h2"
                  style={{ color: isDark ? Colors.dark.success : Colors.light.success }}
                >
                  {correctWords}
                </ThemedText>
              </View>
              <View style={styles.resultItem}>
                <ThemedText type="label" style={[styles.resultLabel, { color: theme.textSecondary }]}>
                  {t.wpm}
                </ThemedText>
                <ThemedText
                  type="h2"
                  style={{ color: isDark ? Colors.dark.primary : Colors.light.primary }}
                >
                  {wpm}
                </ThemedText>
              </View>
              <View style={styles.resultItem}>
                <ThemedText type="label" style={[styles.resultLabel, { color: theme.textSecondary }]}>
                  {t.seconds}
                </ThemedText>
                <ThemedText type="h2">{seconds}</ThemedText>
              </View>
            </View>
          </View>
        </Animated.View>

        <View style={{ height: 100 }} />
      </ScreenKeyboardAwareScrollView>

      <AnimatedPressable
        onPress={() => navigation.navigate("History")}
        onPressIn={() => {
          fabScale.value = withSpring(0.95);
        }}
        onPressOut={() => {
          fabScale.value = withSpring(1);
        }}
        style={[
          styles.fab,
          fabAnimatedStyle,
          {
            backgroundColor: isDark ? Colors.dark.primary : Colors.light.primary,
            bottom: insets.bottom + Spacing.xl,
            right: isRTL ? undefined : Spacing.lg,
            left: isRTL ? Spacing.lg : undefined,
          },
          Shadows.fab,
        ]}
      >
        <Feather name="list" size={24} color="#FFFFFF" />
      </AnimatedPressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing["3xl"],
  },
  subtitleContainer: {
    marginBottom: Spacing.lg,
    alignItems: "center",
  },
  subtitle: {
    textAlign: "center",
  },
  card: {
    borderRadius: BorderRadius.sm,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  timerCard: {
    alignItems: "center",
  },
  formRow: {
    marginBottom: Spacing.md,
  },
  label: {
    marginBottom: Spacing.xs,
  },
  input: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
  },
  dateField: {
    justifyContent: "center",
  },
  twoColumns: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  column: {
    flex: 1,
  },
  timerContainer: {
    alignItems: "center",
    marginBottom: Spacing.xl,
    paddingVertical: Spacing.lg,
  },
  timerText: {
    letterSpacing: 2,
  },
  buttonRow: {
    flexDirection: "row",
    gap: Spacing.md,
    flexWrap: "wrap",
    justifyContent: "center",
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    paddingHorizontal: Spacing.xl,
    borderRadius: BorderRadius.xs,
    minWidth: 120,
  },
  startButton: {},
  stopButton: {},
  calculateButton: {},
  buttonIcon: {
    marginRight: Spacing.sm,
  },
  buttonText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 15,
  },
  resultsContainer: {
    marginTop: Spacing.sm,
  },
  resultsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  resultItem: {
    alignItems: "center",
  },
  resultLabel: {
    marginBottom: Spacing.xs,
    textAlign: "center",
  },
  fab: {
    position: "absolute",
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  headerButton: {
    padding: Spacing.sm,
  },
  languageChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  languageChipText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 13,
  },
});
