import React, { useState, useMemo } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  FlatList,
  Modal,
  Alert,
  Platform,
  ScrollView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import * as Sharing from "expo-sharing";
import { documentDirectory, writeAsStringAsync } from "expo-file-system/legacy";
import * as Haptics from "expo-haptics";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  FadeIn,
  FadeOut,
  Layout,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAssessment, AssessmentRecord } from "@/contexts/AssessmentContext";
import { Colors, Spacing, BorderRadius, Shadows } from "@/constants/theme";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function HistoryCard({
  record,
  onDelete,
}: {
  record: AssessmentRecord;
  onDelete: () => void;
}) {
  const { theme, isDark } = useTheme();
  const { t, isRTL } = useLanguage();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View
      entering={FadeIn.duration(300)}
      exiting={FadeOut.duration(200)}
      layout={Layout.springify()}
    >
      <AnimatedPressable
        onPressIn={() => {
          scale.value = withSpring(0.98);
        }}
        onPressOut={() => {
          scale.value = withSpring(1);
        }}
        style={[
          styles.historyCard,
          animatedStyle,
          { backgroundColor: theme.backgroundDefault },
          Shadows.card,
        ]}
      >
        <View style={[styles.cardHeader, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <ThemedText type="h4" style={styles.cardName}>
            {record.learnerName}
          </ThemedText>
          <Pressable
            onPress={onDelete}
            hitSlop={12}
            style={({ pressed }) => [
              styles.deleteButton,
              { opacity: pressed ? 0.6 : 1 },
            ]}
          >
            <Feather
              name="trash-2"
              size={18}
              color={isDark ? Colors.dark.accent : Colors.light.accent}
            />
          </Pressable>
        </View>

        <ThemedText type="caption" style={{ color: theme.textSecondary, textAlign: isRTL ? "right" : "left" }}>
          {record.date}
        </ThemedText>

        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <ThemedText
              type="h3"
              style={{ color: isDark ? Colors.dark.primary : Colors.light.primary }}
            >
              {record.wpm}
            </ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary }}>
              {t.wpm}
            </ThemedText>
          </View>
          <View style={styles.statItem}>
            <ThemedText
              type="h3"
              style={{ color: isDark ? Colors.dark.success : Colors.light.success }}
            >
              {record.correctWords}
            </ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary }}>
              {t.correctWords}
            </ThemedText>
          </View>
          <View style={styles.statItem}>
            <ThemedText type="h3">{record.seconds}s</ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary }}>
              {t.time}
            </ThemedText>
          </View>
        </View>
      </AnimatedPressable>
    </Animated.View>
  );
}

function RankingCard({
  record,
  rank,
}: {
  record: AssessmentRecord;
  rank: number;
}) {
  const { theme, isDark } = useTheme();
  const { t, isRTL } = useLanguage();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const getMedalColor = (position: number) => {
    switch (position) {
      case 1:
        return "#FFD700";
      case 2:
        return "#C0C0C0";
      case 3:
        return "#CD7F32";
      default:
        return theme.textSecondary;
    }
  };

  const getMedalIcon = (position: number): "award" | "star" | "circle" => {
    if (position <= 3) return "award";
    return "circle";
  };

  return (
    <Animated.View
      entering={FadeIn.duration(300).delay(rank * 50)}
      layout={Layout.springify()}
    >
      <AnimatedPressable
        onPressIn={() => {
          scale.value = withSpring(0.98);
        }}
        onPressOut={() => {
          scale.value = withSpring(1);
        }}
        style={[
          styles.rankingCard,
          animatedStyle,
          { backgroundColor: theme.backgroundDefault },
          rank <= 3 && {
            borderLeftWidth: 4,
            borderLeftColor: getMedalColor(rank),
          },
          Shadows.card,
        ]}
      >
        <View style={[styles.rankingRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <View style={[styles.rankBadge, { backgroundColor: getMedalColor(rank) + "20" }]}>
            <Feather
              name={getMedalIcon(rank)}
              size={rank <= 3 ? 20 : 14}
              color={getMedalColor(rank)}
            />
            <ThemedText
              type="h4"
              style={[styles.rankNumber, { color: getMedalColor(rank) }]}
            >
              {rank}
            </ThemedText>
          </View>

          <View style={[styles.rankingInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
            <ThemedText type="h4">{record.learnerName}</ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary }}>
              {record.correctWords} {t.correctWords}
            </ThemedText>
          </View>

          <View style={styles.wpmBadge}>
            <ThemedText
              type="h3"
              style={{ color: isDark ? Colors.dark.primary : Colors.light.primary }}
            >
              {record.wpm}
            </ThemedText>
            <ThemedText type="caption" style={{ color: theme.textSecondary, fontSize: 10 }}>
              {t.wpm}
            </ThemedText>
          </View>
        </View>
      </AnimatedPressable>
    </Animated.View>
  );
}

export default function HistoryScreen() {
  const navigation = useNavigation();
  const { theme, isDark } = useTheme();
  const { t, isRTL } = useLanguage();
  const { records, deleteRecord, clearRecords, getRankingsByDate, getUniquesDates } = useAssessment();
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();

  const [showClearModal, setShowClearModal] = useState(false);
  const [viewMode, setViewMode] = useState<"list" | "ranking">("list");
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const uniqueDates = useMemo(() => getUniquesDates(), [records]);
  
  const currentDate = useMemo(() => {
    if (selectedDate) return selectedDate;
    if (uniqueDates.length > 0) return uniqueDates[0];
    return null;
  }, [selectedDate, uniqueDates]);

  const rankings = useMemo(() => {
    if (!currentDate) return [];
    return getRankingsByDate(currentDate);
  }, [currentDate, records]);

  const handleExportCSV = async () => {
    if (records.length === 0) {
      Alert.alert(t.noHistory);
      return;
    }

    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    const headers = "Name,Date,Total Words,Errors,Correct Words,WPM,Seconds\n";
    const rows = records
      .map(
        (r) =>
          `"${r.learnerName}","${r.date}",${r.totalWords},${r.errors},${r.correctWords},${r.wpm},${r.seconds}`
      )
      .join("\n");
    const csvContent = headers + rows;

    if (Platform.OS === "web") {
      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "talaka_fluency_data.csv";
      a.click();
      URL.revokeObjectURL(url);
      Alert.alert(t.exportSuccess);
    } else {
      try {
        const fileUri = documentDirectory + "talaka_fluency_data.csv";
        await writeAsStringAsync(fileUri, csvContent);
        await Sharing.shareAsync(fileUri);
      } catch (error) {
        console.error("Export error:", error);
      }
    }
  };

  const handleClearConfirm = () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    }
    clearRecords();
    setShowClearModal(false);
  };

  const handleDeleteRecord = (id: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    deleteRecord(id);
  };

  const toggleViewMode = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setViewMode(viewMode === "list" ? "ranking" : "list");
  };

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <Pressable
          onPress={() => navigation.goBack()}
          style={({ pressed }) => [
            styles.headerButton,
            { opacity: pressed ? 0.7 : 1 },
          ]}
        >
          <Feather name="x" size={24} color={theme.text} />
        </Pressable>
      ),
      headerRight: () => (
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Pressable
            onPress={toggleViewMode}
            style={({ pressed }) => [
              styles.headerButton,
              { opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Feather
              name={viewMode === "list" ? "award" : "list"}
              size={22}
              color={theme.text}
            />
          </Pressable>
          <Pressable
            onPress={handleExportCSV}
            style={({ pressed }) => [
              styles.headerButton,
              { opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Feather name="download" size={22} color={theme.text} />
          </Pressable>
        </View>
      ),
    });
  }, [navigation, theme, records, viewMode]);

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <View
        style={[
          styles.emptyIconContainer,
          { backgroundColor: theme.backgroundSecondary },
        ]}
      >
        <Feather
          name="clipboard"
          size={48}
          color={theme.textSecondary}
        />
      </View>
      <ThemedText type="h4" style={styles.emptyTitle}>
        {t.noHistory}
      </ThemedText>
      <ThemedText type="body" style={[styles.emptyDesc, { color: theme.textSecondary }]}>
        {t.noHistoryDesc}
      </ThemedText>
    </View>
  );

  const renderDateSelector = () => (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.dateSelector}
    >
      {uniqueDates.map((date) => (
        <Pressable
          key={date}
          onPress={() => setSelectedDate(date)}
          style={({ pressed }) => [
            styles.dateChip,
            {
              backgroundColor:
                currentDate === date
                  ? isDark
                    ? Colors.dark.primary
                    : Colors.light.primary
                  : theme.backgroundSecondary,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <ThemedText
            style={[
              styles.dateChipText,
              {
                color: currentDate === date ? "#FFFFFF" : theme.text,
              },
            ]}
          >
            {date}
          </ThemedText>
        </Pressable>
      ))}
    </ScrollView>
  );

  const renderRankingList = () => (
    <FlatList
      data={rankings}
      keyExtractor={(item) => item.id}
      renderItem={({ item, index }) => (
        <RankingCard record={item} rank={index + 1} />
      )}
      ListHeaderComponent={
        <View>
          <ThemedText type="h4" style={[styles.sectionTitle, { textAlign: isRTL ? "right" : "left" }]}>
            {t.rankingByDay}
          </ThemedText>
          {renderDateSelector()}
        </View>
      }
      contentContainerStyle={[
        styles.listContent,
        {
          paddingTop: Spacing.xl,
          paddingBottom: insets.bottom + Spacing["3xl"] + 60,
        },
        rankings.length === 0 && styles.emptyListContent,
      ]}
      ListEmptyComponent={
        <View style={styles.noRankingContainer}>
          <Feather name="bar-chart-2" size={48} color={theme.textSecondary} />
          <ThemedText type="body" style={{ color: theme.textSecondary, marginTop: Spacing.md }}>
            {t.noRankingData}
          </ThemedText>
        </View>
      }
      showsVerticalScrollIndicator={false}
    />
  );

  return (
    <ThemedView style={styles.container}>
      {viewMode === "list" ? (
        <FlatList
          data={records}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <HistoryCard
              record={item}
              onDelete={() => handleDeleteRecord(item.id)}
            />
          )}
          ListHeaderComponent={
            records.length > 0 ? (
              <ThemedText type="caption" style={[styles.allRecordsTitle, { color: theme.textSecondary }]}>
                {t.allRecords} ({records.length})
              </ThemedText>
            ) : null
          }
          contentContainerStyle={[
            styles.listContent,
            {
              paddingTop: Spacing.xl,
              paddingBottom: insets.bottom + Spacing["3xl"] + 60,
            },
            records.length === 0 && styles.emptyListContent,
          ]}
          ListEmptyComponent={renderEmptyState}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        renderRankingList()
      )}

      {records.length > 0 ? (
        <View
          style={[
            styles.footer,
            {
              paddingBottom: insets.bottom + Spacing.lg,
              backgroundColor: theme.backgroundRoot,
              borderTopColor: theme.border,
            },
          ]}
        >
          <Pressable
            onPress={() => setShowClearModal(true)}
            style={({ pressed }) => [
              styles.clearButton,
              {
                borderColor: isDark ? Colors.dark.accent : Colors.light.accent,
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.98 : 1 }],
              },
            ]}
          >
            <Feather
              name="trash"
              size={18}
              color={isDark ? Colors.dark.accent : Colors.light.accent}
              style={{ marginRight: Spacing.sm }}
            />
            <ThemedText
              style={{
                color: isDark ? Colors.dark.accent : Colors.light.accent,
                fontWeight: "600",
              }}
            >
              {t.clearHistory}
            </ThemedText>
          </Pressable>
        </View>
      ) : null}

      <Modal
        visible={showClearModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowClearModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalContent,
              { backgroundColor: theme.backgroundDefault },
              Shadows.modal,
            ]}
          >
            <ThemedText type="h4" style={styles.modalTitle}>
              {t.confirmClear}
            </ThemedText>
            <ThemedText
              type="body"
              style={[styles.modalDesc, { color: theme.textSecondary }]}
            >
              {t.confirmClearDesc}
            </ThemedText>

            <View style={styles.modalButtons}>
              <Pressable
                onPress={() => setShowClearModal(false)}
                style={({ pressed }) => [
                  styles.modalButton,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <ThemedText style={{ fontWeight: "600" }}>{t.cancel}</ThemedText>
              </Pressable>
              <Pressable
                onPress={handleClearConfirm}
                style={({ pressed }) => [
                  styles.modalButton,
                  {
                    backgroundColor: isDark ? Colors.dark.accent : Colors.light.accent,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <ThemedText style={{ color: "#FFFFFF", fontWeight: "600" }}>
                  {t.confirm}
                </ThemedText>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: Spacing.xl,
  },
  emptyListContent: {
    flex: 1,
    justifyContent: "center",
  },
  historyCard: {
    borderRadius: BorderRadius.sm,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  cardHeader: {
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xs,
  },
  cardName: {
    flex: 1,
  },
  deleteButton: {
    padding: Spacing.xs,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginTop: Spacing.lg,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: "rgba(128, 128, 128, 0.15)",
  },
  statItem: {
    alignItems: "center",
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: Spacing["2xl"],
  },
  emptyIconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  emptyDesc: {
    textAlign: "center",
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingTop: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderTopWidth: 1,
  },
  clearButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.xs,
    borderWidth: 1.5,
  },
  headerButton: {
    padding: Spacing.sm,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.xl,
  },
  modalContent: {
    width: "100%",
    maxWidth: 340,
    borderRadius: BorderRadius.md,
    padding: Spacing["2xl"],
  },
  modalTitle: {
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  modalDesc: {
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  modalButtons: {
    flexDirection: "row",
    gap: Spacing.md,
  },
  modalButton: {
    flex: 1,
    height: Spacing.buttonHeight,
    borderRadius: BorderRadius.xs,
    alignItems: "center",
    justifyContent: "center",
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  dateSelector: {
    paddingBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  dateChip: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  dateChipText: {
    fontSize: 13,
    fontWeight: "500",
  },
  rankingCard: {
    borderRadius: BorderRadius.sm,
    padding: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  rankingRow: {
    alignItems: "center",
    gap: Spacing.md,
  },
  rankBadge: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  rankNumber: {
    fontSize: 12,
    fontWeight: "700",
    marginTop: 2,
  },
  rankingInfo: {
    flex: 1,
  },
  wpmBadge: {
    alignItems: "center",
  },
  noRankingContainer: {
    alignItems: "center",
    justifyContent: "center",
    padding: Spacing["3xl"],
  },
  allRecordsTitle: {
    marginBottom: Spacing.md,
    textAlign: "center",
  },
});
