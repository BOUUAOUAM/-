import React, { useState } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  TextInput,
  Switch,
  Alert,
  Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ScreenScrollView } from "@/components/ScreenScrollView";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAssessment } from "@/contexts/AssessmentContext";
import { Colors, Spacing, BorderRadius, Shadows } from "@/constants/theme";

function SettingsSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const { theme } = useTheme();

  return (
    <View style={styles.section}>
      <ThemedText
        type="label"
        style={[styles.sectionTitle, { color: theme.textSecondary }]}
      >
        {title}
      </ThemedText>
      <View
        style={[
          styles.sectionContent,
          { backgroundColor: theme.backgroundDefault },
          Shadows.card,
        ]}
      >
        {children}
      </View>
    </View>
  );
}

function SettingsRow({
  icon,
  label,
  value,
  onPress,
  showChevron = false,
  isDestructive = false,
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  value?: React.ReactNode;
  onPress?: () => void;
  showChevron?: boolean;
  isDestructive?: boolean;
}) {
  const { theme, isDark } = useTheme();
  const { isRTL } = useLanguage();

  const iconColor = isDestructive
    ? isDark
      ? Colors.dark.accent
      : Colors.light.accent
    : isDark
      ? Colors.dark.primary
      : Colors.light.primary;

  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [
        styles.settingsRow,
        { flexDirection: isRTL ? "row-reverse" : "row" },
        { opacity: pressed && onPress ? 0.7 : 1 },
      ]}
    >
      <View style={[styles.rowLeft, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <View
          style={[
            styles.iconContainer,
            { backgroundColor: `${iconColor}15` },
          ]}
        >
          <Feather name={icon} size={18} color={iconColor} />
        </View>
        <ThemedText
          style={[
            styles.rowLabel,
            isDestructive && { color: iconColor },
            { textAlign: isRTL ? "right" : "left", marginLeft: isRTL ? 0 : Spacing.md, marginRight: isRTL ? Spacing.md : 0 },
          ]}
        >
          {label}
        </ThemedText>
      </View>
      <View style={[styles.rowRight, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
        {value}
        {showChevron ? (
          <Feather
            name={isRTL ? "chevron-left" : "chevron-right"}
            size={18}
            color={theme.textSecondary}
            style={{ marginLeft: isRTL ? 0 : Spacing.sm, marginRight: isRTL ? Spacing.sm : 0 }}
          />
        ) : null}
      </View>
    </Pressable>
  );
}

export default function SettingsScreen() {
  const { theme, isDark } = useTheme();
  const { t, language, setLanguage, isRTL } = useLanguage();
  const { clearRecords, records } = useAssessment();

  const [defaultAssessor, setDefaultAssessor] = useState("");

  const handleLanguageChange = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setLanguage(language === "ar" ? "fr" : "ar");
  };

  const handleClearHistory = () => {
    if (records.length === 0) {
      Alert.alert(t.noHistory);
      return;
    }

    Alert.alert(t.confirmClear, t.confirmClearDesc, [
      { text: t.cancel, style: "cancel" },
      {
        text: t.confirm,
        style: "destructive",
        onPress: () => {
          if (Platform.OS !== "web") {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          }
          clearRecords();
          Alert.alert(t.resultsCleared);
        },
      },
    ]);
  };

  return (
    <ScreenScrollView contentContainerStyle={styles.content}>
      <SettingsSection title={t.languageSettings}>
        <SettingsRow
          icon="globe"
          label={t.language}
          value={
            <Pressable
              onPress={handleLanguageChange}
              style={({ pressed }) => [
                styles.languageToggle,
                {
                  backgroundColor: isDark ? Colors.dark.primary : Colors.light.primary,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <ThemedText style={styles.languageToggleText}>
                {language === "ar" ? "العربية" : "Français"}
              </ThemedText>
            </Pressable>
          }
        />
      </SettingsSection>

      <SettingsSection title={t.dataManagement}>
        <View style={styles.inputRow}>
          <View style={[styles.rowLeft, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <View
              style={[
                styles.iconContainer,
                { backgroundColor: `${isDark ? Colors.dark.primary : Colors.light.primary}15` },
              ]}
            >
              <Feather
                name="user"
                size={18}
                color={isDark ? Colors.dark.primary : Colors.light.primary}
              />
            </View>
            <View style={[styles.inputContainer, { marginLeft: isRTL ? 0 : Spacing.md, marginRight: isRTL ? Spacing.md : 0 }]}>
              <ThemedText type="label" style={{ marginBottom: Spacing.xs, textAlign: isRTL ? "right" : "left" }}>
                {t.defaultAssessor}
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                    textAlign: isRTL ? "right" : "left",
                  },
                ]}
                value={defaultAssessor}
                onChangeText={setDefaultAssessor}
                placeholder={t.defaultAssessorPlaceholder}
                placeholderTextColor={theme.textSecondary}
              />
            </View>
          </View>
        </View>

        <View style={styles.divider} />

        <SettingsRow
          icon="trash-2"
          label={t.clearHistory}
          onPress={handleClearHistory}
          showChevron
          isDestructive
        />
      </SettingsSection>

      <SettingsSection title={t.about}>
        <SettingsRow
          icon="info"
          label={t.version}
          value={<ThemedText style={{ color: theme.textSecondary }}>1.0.0</ThemedText>}
        />

        <View style={styles.divider} />

        <View style={styles.creditsRow}>
          <View
            style={[
              styles.iconContainer,
              { backgroundColor: `${isDark ? Colors.dark.info : Colors.light.info}15` },
            ]}
          >
            <Feather
              name="heart"
              size={18}
              color={isDark ? Colors.dark.info : Colors.light.info}
            />
          </View>
          <View style={[styles.creditsContent, { marginLeft: isRTL ? 0 : Spacing.md, marginRight: isRTL ? Spacing.md : 0 }]}>
            <ThemedText style={{ marginBottom: Spacing.xs, textAlign: isRTL ? "right" : "left" }}>
              {t.credits}
            </ThemedText>
            <ThemedText
              type="caption"
              style={{ color: theme.textSecondary, textAlign: isRTL ? "right" : "left" }}
            >
              {t.creditsText}
            </ThemedText>
          </View>
        </View>
      </SettingsSection>

      <View style={{ height: Spacing["3xl"] }} />
    </ScreenScrollView>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingTop: Spacing.lg,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.sm,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    fontSize: 12,
  },
  sectionContent: {
    borderRadius: BorderRadius.sm,
    overflow: "hidden",
  },
  settingsRow: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    alignItems: "center",
    justifyContent: "space-between",
  },
  rowLeft: {
    alignItems: "center",
    flex: 1,
  },
  rowRight: {
    alignItems: "center",
  },
  rowLabel: {
    fontSize: 16,
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  languageToggle: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  languageToggleText: {
    color: "#FFFFFF",
    fontWeight: "600",
    fontSize: 14,
  },
  divider: {
    height: 1,
    backgroundColor: "rgba(128, 128, 128, 0.15)",
    marginHorizontal: Spacing.lg,
  },
  inputRow: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  inputContainer: {
    flex: 1,
  },
  textInput: {
    height: 40,
    borderRadius: BorderRadius.xs,
    borderWidth: 1,
    paddingHorizontal: Spacing.md,
    fontSize: 14,
  },
  creditsRow: {
    flexDirection: "row",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    alignItems: "flex-start",
  },
  creditsContent: {
    flex: 1,
  },
});
